"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Gift, Heart, MapPin, Sparkles, CalendarIcon, Mail, Facebook, Instagram } from "lucide-react"
import { useEffect, useState } from "react"
import { MapLocation } from "@/components/map-location"
import Link from "next/link"
import Image from "next/image"

export default function BuxtehudeAdventskalender() {
  const [scrollY, setScrollY] = useState(0)

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY)
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <div className="min-h-screen bg-background">
      {/* Sticky Navigation */}
      <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Gift className="h-6 w-6 text-christmas-red" />
              <span className="font-bold text-xl">Buxtehude</span>
            </div>
            <div className="hidden md:flex items-center gap-6 text-sm">
              <a href="#kalender" className="hover:text-christmas-red transition-colors">
                Kalender
              </a>
              <a href="#so-funktionierts" className="hover:text-christmas-red transition-colors">
                So funktioniert's
              </a>
              <a href="#spenden" className="hover:text-christmas-red transition-colors">
                Spenden
              </a>
              <a href="#teilnehmer" className="hover:text-christmas-red transition-colors">
                Unternehmen
              </a>
              <a href="#gewinnspiele" className="hover:text-christmas-red transition-colors">
                Gewinnspiele
              </a>
              <a href="#verkaufsstellen" className="hover:text-christmas-red transition-colors">
                Verkaufsstellen
              </a>
              <a href="#faq" className="hover:text-christmas-red transition-colors">
                FAQ
              </a>
              <a href="#kontakt" className="hover:text-christmas-red transition-colors">
                Kontakt
              </a>
            </div>
          </div>
        </div>
      </nav>

      <section id="kalender" className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
        {/* Background Image with Overlay */}
        <div className="absolute inset-0">
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Buxtehude%20Weihnachtsmarkt%20Bild%201-i55XYrQYFWjeaNgmcOqaNfhCIyaIX7.jpg"
            alt="Buxtehude Weihnachtsmarkt"
            fill
            className="object-cover"
            style={{ transform: `translateY(${scrollY * 0.5}px)` }}
            priority
          />
          {/* Dark overlay for text readability */}
          <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/60 to-black/80" />
        </div>

        {/* Parallax decorative elements */}
        <div
          className="absolute top-20 left-10 w-32 h-32 rounded-full bg-christmas-green/20 blur-3xl"
          style={{ transform: `translateY(${scrollY * 0.3}px)` }}
        />
        <div
          className="absolute bottom-20 right-10 w-40 h-40 rounded-full bg-christmas-red/20 blur-3xl"
          style={{ transform: `translateY(${scrollY * 0.2}px)` }}
        />

        <div className="container mx-auto px-4 py-20 relative z-10">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-christmas-green/90 rounded-full text-sm text-white border border-christmas-green/50">
              <Sparkles className="h-4 w-4" />
              <span>Der neue Buxtehude Erlebnis-Adventskalender 2025!</span>
            </div>

            <h1 className="text-5xl md:text-7xl font-bold text-balance leading-tight text-white drop-shadow-lg">
              24 Erlebnisse, über 200 € Wert – für nur <span className="text-christmas-gold">21,50 €</span>
            </h1>

            <p className="text-xl md:text-2xl text-white/95 text-pretty max-w-3xl mx-auto leading-relaxed drop-shadow-md">
              24 Mal Erlebnisse, Geschenke, Vorteile – und das gute Gefühl, beim Genuss etwas Gutes getan zu haben.
            </p>

            <p className="text-lg text-white/90 drop-shadow-md">Hol ihn dir als Geschenk oder zum Selbernutzen!</p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center pt-4">
              <Button
                size="lg"
                className="bg-christmas-red hover:bg-christmas-red/90 text-white px-8 h-14 text-lg rounded-xl shadow-2xl hover:shadow-xl transition-all hover:scale-105"
              >
                <Gift className="h-5 w-5 mr-2" />
                Jetzt kaufen!
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-2 border-white text-white hover:bg-white hover:text-christmas-green h-14 px-8 text-lg rounded-xl bg-transparent backdrop-blur-sm transition-all"
                asChild
              >
                <a href="#verkaufsstellen">Verkaufsstellen vor Ort</a>
              </Button>
            </div>

            <div className="flex flex-col sm:flex-row gap-6 justify-center items-center pt-8 text-sm">
              <div className="flex items-center gap-2 text-white/90 drop-shadow-md">
                <CalendarIcon className="h-5 w-5 text-christmas-gold" />
                <span>Nur solange der Vorrat reicht</span>
              </div>
              <div className="flex items-center gap-2 text-white/90 drop-shadow-md">
                <Gift className="h-5 w-5 text-christmas-gold" />
                <span>Gesamtwert ca. 200 €</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* So funktioniert's */}
      <section id="so-funktionierts" className="py-24 bg-muted/30 relative overflow-hidden">
        <div
          className="absolute -top-20 -right-20 w-64 h-64 rounded-full bg-christmas-gold/8 blur-3xl"
          style={{ transform: `translateY(${scrollY * 0.1}px)` }}
        />
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">So funktioniert's</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto text-pretty">
              In vier einfachen Schritten zu deinem Adventskalender-Erlebnis
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-6xl mx-auto">
            {[
              {
                icon: Gift,
                title: "1. Kalender kaufen",
                desc: "Online oder vor Ort in teilnehmenden Geschäften",
                color: "christmas-red",
              },
              {
                icon: CalendarIcon,
                title: "2. Türchen öffnen",
                desc: "Jeden Tag im Dezember ein neues Erlebnis entdecken",
                color: "christmas-green",
              },
              {
                icon: MapPin,
                title: "3. Gutscheine einlösen",
                desc: "In teilnehmenden Buxtehuder Unternehmen",
                color: "christmas-gold",
              },
              {
                icon: Heart,
                title: "4. Gutes tun",
                desc: "Gleichzeitig lokale Projekte durch Spenden unterstützen",
                color: "christmas-red",
              },
            ].map((step, i) => (
              <Card key={i} className="border-2 hover:border-christmas-red/50 transition-all hover:shadow-lg bg-card">
                <CardContent className="pt-8 pb-6 text-center space-y-4">
                  <div
                    className={`inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-${step.color}/10 text-${step.color}`}
                  >
                    <step.icon className="h-8 w-8" />
                  </div>
                  <h3 className="font-bold text-lg">{step.title}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">{step.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section id="spenden" className="py-24 relative overflow-hidden">
        <div
          className="absolute top-40 left-20 w-48 h-48 rounded-full bg-christmas-green/8 blur-3xl"
          style={{ transform: `translateY(${scrollY * 0.15}px)` }}
        />
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">Spenden für gute Zwecke</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed text-pretty">
              Unsere Adventskalender schaffen Mehrwert und Erlebnisse für die Käufer, stärken lokale Unternehmen – vor
              allem in den Innenstädten – und unterstützen durch Spenden lokale, ehrenamtliche Arbeit für gute, soziale
              Zwecke.
            </p>
          </div>

          <div className="max-w-4xl mx-auto mb-12 p-6 bg-christmas-red/5 rounded-2xl border border-christmas-red/20">
            <p className="text-center text-lg font-medium">
              <Heart className="inline h-5 w-5 text-christmas-red mr-2" />
              Unsere Spenden erfolgen aus den Erlösen der Kalenderverkäufe. Je mehr Kalender wir verkaufen, desto höher
              sind unsere Spenden!
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <Card className="border-2 border-christmas-green/30 bg-gradient-to-br from-christmas-green/5 to-transparent hover:shadow-lg transition-shadow">
              <CardContent className="pt-8 pb-8 space-y-4">
                <div className="flex justify-center mb-4">
                  <div className="relative w-32 h-32">
                    <Image
                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Nr%2010%20BSV-LVxfjAhFlDblp78yo3GjCnUW2p6swc.png"
                      alt="Buxtehuder SV Logo"
                      fill
                      className="object-contain"
                    />
                  </div>
                </div>
                <h3 className="text-2xl font-bold text-center">Buxtehuder SV</h3>
                <p className="text-muted-foreground leading-relaxed text-center">
                  Wir unterstützen die großartige Jugendarbeit des Buxtehuder SV.
                </p>
              </CardContent>
            </Card>

            <Card className="border-2 border-christmas-red/30 bg-gradient-to-br from-christmas-red/5 to-transparent hover:shadow-lg transition-shadow">
              <CardContent className="pt-8 pb-8 space-y-4">
                <div className="flex justify-center mb-4">
                  <div className="relative w-32 h-32">
                    <Image
                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Altstadtverein-OD9cxMgFbil8KZGU75mlr9JY5QCzyx.png"
                      alt="Altstadtverein Buxtehude Logo"
                      fill
                      className="object-contain"
                    />
                  </div>
                </div>
                <h3 className="text-2xl font-bold text-center">Altstadtverein</h3>
                <p className="text-muted-foreground leading-relaxed text-center">
                  Wir unterstützen den Altstadtverein bei seiner Arbeit, die Innenstadt für alle noch liebenswerter zu
                  machen.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Teilnehmende Unternehmen */}
      <section id="teilnehmer" className="py-24 bg-muted/30 relative overflow-hidden">
        <div
          className="absolute bottom-20 left-10 w-56 h-56 rounded-full bg-christmas-gold/8 blur-3xl"
          style={{ transform: `translateY(${scrollY * 0.08}px)` }}
        />
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">Teilnehmende Unternehmen</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
              Wir haben bewusst Unternehmen aus vielen verschiedenen Branchen gebeten, Geschenke für die Buxtehuder
              bereitzustellen. Allen Teilnehmern ein großes Dankeschön!
            </p>
          </div>

          <div className="max-w-6xl mx-auto grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {[
              "Amadeus",
              "Bunte Kinderkiste",
              "Buxtehude SV",
              "Café Docé",
              "Das Futterhaus Buxtehude",
              "Ernsting's family",
              "EURONICS Wiegel",
              "Flamingo Grill",
              "Hermann – Schönes Leben",
              "Kreativ Bastelparadies",
              "lenya natürlich!",
              "Ludwig von Karpff",
              "Märchenhaft",
              "Mundfein Pizzawerkstatt",
              "Nähatelier kreativer Faden",
              "Obsthof Brunckhorst",
              "PfefferTörtchen",
              "Ringfoto Schattke",
              "S Fachl",
              "Smash'lt Burger",
              "Stil & Blüte",
              "Sushi Palace",
              "Taj Mahal",
            ].map((company, i) => (
              <Card key={i} className="hover:border-christmas-red/50 transition-all hover:shadow-md bg-card">
                <CardContent className="p-6 text-center">
                  <p className="font-medium text-sm">{company}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Gewinnspiele */}
      <section id="gewinnspiele" className="py-24">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">Gewinnspiele</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">Adventskalender gewinnen</p>
          </div>

          <div className="max-w-4xl mx-auto space-y-8">
            <Card className="border-2 bg-card shadow-lg">
              <CardContent className="pt-8 pb-8 space-y-6">
                <p className="text-lg leading-relaxed">
                  Unter den Kunden verschiedener teilnehmender Unternehmen verlosen wir jeweils einen unserer Buxtehuder
                  Erlebnis-Adventskalender 2025. Die Teilnahme ist einfach:
                </p>

                <div className="space-y-4">
                  {[
                    "Ab dem Beginn des jeweiligen Gewinnspiels etwas im Unternehmen kaufen und den Kassenbon fotografieren.",
                    "Das Bild des Kassenbons bei Facebook in unserem Account Buxtehude Erlebnis-Adventskalender 2025 oder bei Instagram Buxtehude_Adventskalender posten.",
                    "Dem jeweiligen Kanal zusätzlich folgen.",
                  ].map((step, i) => (
                    <div key={i} className="flex gap-4">
                      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-christmas-red text-white flex items-center justify-center font-bold text-sm">
                        {i + 1}
                      </div>
                      <p className="flex-1 pt-1 text-muted-foreground leading-relaxed">{step}</p>
                    </div>
                  ))}
                </div>

                <div className="pt-4 px-6 py-4 bg-muted rounded-xl">
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    <strong>Rechtlicher Hinweis:</strong> Unter allen Teilnehmern verlosen wir die im Gewinnspiel
                    angegebene Menge an Kalendern. Der Rechtsweg ist ausgeschlossen, Teilnahme ab 18 Jahren.
                  </p>
                </div>

                <div className="pt-4">
                  <h4 className="font-semibold mb-3">Teilnehmende Unternehmen mit Gewinnspiel:</h4>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2">
                      <Gift className="h-5 w-5 text-christmas-red flex-shrink-0" />
                      <span>Sushi Palace Buxtehude</span>
                    </li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Verkaufsstellen */}
      <section id="verkaufsstellen" className="py-24 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">Verkaufsstellen</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
              Unsere Adventskalender kannst du nicht nur online bestellen – du bekommst ihn auch in ausgewählten
              teilnehmenden Geschäften in Buxtehude. Wer Porto und Versand sparen und den Kalender vor dem Kauf sehen
              möchte, besucht eine dieser Verkaufsstellen.
            </p>
          </div>

          <div className="max-w-6xl mx-auto">
            <MapLocation />
          </div>
        </div>
      </section>

      <section className="py-24">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <Accordion type="single" collapsible className="w-full">
              <AccordionItem
                value="prizes"
                className="bg-gradient-to-br from-christmas-gold/10 to-christmas-red/10 border-2 border-christmas-gold/30 rounded-2xl px-6 shadow-lg"
              >
                <AccordionTrigger className="text-left hover:no-underline py-8">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-christmas-gold/20 text-christmas-gold flex items-center justify-center flex-shrink-0">
                      <Gift className="h-6 w-6" />
                    </div>
                    <div>
                      <h3 className="text-2xl md:text-3xl font-bold mb-1">Die 24 Geschenke</h3>
                      <p className="text-sm text-muted-foreground">Klicken um alle Gutscheine zu sehen</p>
                    </div>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="pb-8">
                  <div className="pt-4 space-y-4">
                    <p className="text-muted-foreground leading-relaxed mb-6">
                      <span className="font-semibold text-christmas-red">Spoileralarm!</span> Wenn du wissen möchtest,
                      welche 24 Geschenke dich erwarten, findest du hier alle Gutscheine im Überblick. Für alle
                      Gutscheine gibt es Einlösebedingungen, z.B. den Zeitraum der Gültigkeit. Die genauen Bedingungen
                      sind auf dem jeweiligen Gutschein vermerkt.
                    </p>

                    <div className="grid gap-3">
                      {[
                        { name: "Amadeus", gift: "1 Mal Nachos mit Jalapeno- und Salsa-Sauce" },
                        { name: "Bunte Kinderkiste", gift: "1 große weihnachtliche Überraschungstüte für Kinder" },
                        { name: "Buxtehuder SV", gift: "Beim Kauf deines Tickets ein zweites Ticket gratis dazu" },
                        { name: "Café Docé", gift: "1 Pastei de Natas pro Person für 1–2 Personen" },
                        { name: "Das Futterhaus 1", gift: "1 Spezial-Tüte für Hund oder Katze" },
                        { name: "Das Futterhaus 2", gift: "1 Paket Meisenknödel" },
                        { name: "Ernsting's family", gift: "20 % Rabatt auf deinen Einkauf" },
                        {
                          name: "EURONICS Wiegel",
                          gift: "1 Mal Staubsaugerbeutel oder 20 € Rabatt auf Arbeitskosten bei TV-Service",
                        },
                        {
                          name: "Flamingo Grill",
                          gift: "1 großes Fladenbrot mit 2 Dips (scharf) oder 1 Baklava ab 20 € Rechnungsbetrag",
                        },
                        { name: "Hermann – Schönes Leben", gift: "1 großes Glaswindlicht / Teelicht mit Designoption" },
                        { name: "Kreativ Bastelparadies", gift: "5 € Rabatt" },
                        { name: "lenya natürlich!", gift: "1 Paar Designer-Socken nach Wahl" },
                        { name: "Märchenhaft", gift: "1 Spezial-Knobi-Pitabrot mit Aioli" },
                        { name: "Mundfein Pizzawerkstatt", gift: "1 Pizza 26 cm Margherita, Salami oder Thunfisch" },
                        {
                          name: "Nähatelier kreativer Faden",
                          gift: "Stoff / Material für Kindernähkurs gratis + 25 % Rabatt auf den Kurspreis",
                        },
                        { name: "Obsthof Brunckhorst", gift: "1 große Tüte Äpfel mit einem leckeren Rezept" },
                        { name: "PfefferTörtchen", gift: "1 Stück hausgemachten Kuchen nach Wahl" },
                        { name: "Ringfoto Schattke", gift: "6 Handybilder ausgedruckt" },
                        { name: "S Fachl", gift: "Die Tüte der Woche (Gummibären)" },
                        { name: "Smash'lt Burger", gift: "10 € Rabatt bei Abholung einer Bestellung ab 30 €" },
                        { name: "Stil & Blüte", gift: "1 adventliches Überraschungsgeschenk" },
                        {
                          name: "Sushi Palace",
                          gift: "eine Variante der Tempura-Sushi gratis bei Abholung deiner Sushi-Bestellung",
                        },
                        { name: "Taj Mahal", gift: "1 Vorspeise deiner Wahl aus der Karte gratis im Restaurant" },
                        {
                          name: "Ludwig von Karpff, Weinlager Buxtehude",
                          gift: "1 Flasche Fiore del Sud Primitivo Susumaniello 0,75 l bei Einkauf ab 25 €",
                        },
                      ].map((item, i) => (
                        <Card key={i} className="hover:shadow-md transition-shadow bg-card border">
                          <CardContent className="p-4">
                            <div className="flex flex-col md:flex-row md:items-center gap-3">
                              <div className="flex-shrink-0">
                                <div className="w-8 h-8 rounded-lg bg-christmas-red/10 text-christmas-red flex items-center justify-center font-bold text-sm">
                                  {i + 1}
                                </div>
                              </div>
                              <div className="flex-1 grid md:grid-cols-2 gap-3">
                                <div className="font-semibold text-sm">{item.name}</div>
                                <div className="text-muted-foreground text-sm">{item.gift}</div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="py-24 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">Häufige Fragen</h2>
            <p className="text-xl text-muted-foreground">Alles, was du wissen musst</p>
          </div>

          <div className="max-w-3xl mx-auto">
            <Accordion type="single" collapsible className="space-y-4">
              {[
                {
                  q: "Was kostet der Kalender?",
                  a: "Der Buxtehude Erlebnis-Adventskalender 2025 kostet 21,50 €. Damit erhältst du 24 Gutscheine mit einem Gesamtwert von etwa 200 €.",
                },
                {
                  q: "Wie hoch ist der Gesamtwert der Geschenke?",
                  a: "Der Gesamtwert aller 24 Gutscheine und Geschenke beträgt etwa 200 €. Das ist fast das 10-fache des Kaufpreises!",
                },
                {
                  q: "Wie funktionieren die Gutscheine?",
                  a: "Jeden Tag im Dezember öffnest du ein Türchen und findest einen Gutschein für ein teilnehmendes Unternehmen in Buxtehude. Diesen kannst du dann vor Ort einlösen.",
                },
                {
                  q: "Wie lange sind die Gutscheine gültig?",
                  a: "Die genauen Einlösebedingungen und Gültigkeitszeiträume sind auf jedem einzelnen Gutschein vermerkt. Bitte beachte diese Angaben beim Einlösen.",
                },
                {
                  q: "Wohin fließen die Spenden?",
                  a: "Die Erlöse aus dem Kalenderverkauf unterstützen die Jugendarbeit des Buxtehude SV und den Altstadtverein bei seiner Arbeit für eine lebenswerte Innenstadt. Je mehr Kalender verkauft werden, desto höher sind die Spenden!",
                },
                {
                  q: "Kann ich mehrere Kalender kaufen?",
                  a: "Ja, natürlich! Die Kalender eignen sich hervorragend als Geschenk für Familie, Freunde und Kollegen. Solange der Vorrat reicht, kannst du so viele Kalender kaufen, wie du möchtest.",
                },
                {
                  q: "Ab wann gibt es den Kalender zu kaufen?",
                  a: "Der Kalender ist ab sofort erhältlich – sowohl online als auch in den teilnehmenden Verkaufsstellen in Buxtehude. Aber Achtung: nur solange der Vorrat reicht!",
                },
              ].map((faq, i) => (
                <AccordionItem key={i} value={`item-${i}`} className="bg-card border rounded-xl px-6">
                  <AccordionTrigger className="text-left hover:no-underline py-6">
                    <span className="font-semibold pr-4">{faq.q}</span>
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground pb-6 leading-relaxed">{faq.a}</AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </div>
      </section>

      {/* Kontakt */}
      <section id="kontakt" className="py-24">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto text-center space-y-8">
            <h2 className="text-4xl md:text-5xl font-bold">Kontakt</h2>
            <p className="text-xl text-muted-foreground leading-relaxed">
              Du hast Fragen zum Buxtehude Erlebnis-Adventskalender 2025? Schreib uns gern eine E-Mail.
            </p>

            <Card className="border-2 bg-card shadow-lg">
              <CardContent className="pt-8 pb-8">
                <div className="space-y-4">
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-christmas-red/10 text-christmas-red mx-auto">
                    <Mail className="h-8 w-8" />
                  </div>
                  <a
                    href="mailto:Marc.Maerz@sspeag.onmicrosoft.com"
                    className="text-lg text-christmas-red hover:underline font-medium block"
                  >
                    Marc.Maerz@sspeag.onmicrosoft.com
                  </a>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <footer className="bg-muted/50 border-t border-border py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="grid md:grid-cols-4 gap-8 mb-8">
              {/* Brand */}
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <Gift className="h-6 w-6 text-christmas-red" />
                  <span className="font-bold text-lg">Buxtehude</span>
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Der Erlebnis-Adventskalender für Buxtehude – 24 Geschenke, lokale Unternehmen, gute Zwecke.
                </p>
              </div>

              {/* Quick Links */}
              <div>
                <h4 className="font-semibold mb-4">Schnelllinks</h4>
                <ul className="space-y-2 text-sm">
                  <li>
                    <a href="#kalender" className="text-muted-foreground hover:text-christmas-red transition-colors">
                      Kalender kaufen
                    </a>
                  </li>
                  <li>
                    <a
                      href="#verkaufsstellen"
                      className="text-muted-foreground hover:text-christmas-red transition-colors"
                    >
                      Verkaufsstellen
                    </a>
                  </li>
                  <li>
                    <a href="#faq" className="text-muted-foreground hover:text-christmas-red transition-colors">
                      FAQ
                    </a>
                  </li>
                  <li>
                    <a href="#kontakt" className="text-muted-foreground hover:text-christmas-red transition-colors">
                      Kontakt
                    </a>
                  </li>
                </ul>
              </div>

              {/* Über uns */}
              <div>
                <h4 className="font-semibold mb-4">Über uns</h4>
                <ul className="space-y-2 text-sm">
                  <li>
                    <a href="#spenden" className="text-muted-foreground hover:text-christmas-red transition-colors">
                      Spendenprojekte
                    </a>
                  </li>
                  <li>
                    <a href="#teilnehmer" className="text-muted-foreground hover:text-christmas-red transition-colors">
                      Teilnehmende Unternehmen
                    </a>
                  </li>
                  <li>
                    <Link
                      href="/impressum"
                      className="text-muted-foreground hover:text-christmas-red transition-colors"
                    >
                      Impressum
                    </Link>
                  </li>
                </ul>
              </div>

              {/* Social Media */}
              <div>
                <h4 className="font-semibold mb-4">Folge uns</h4>
                <div className="flex gap-3">
                  <a
                    href="https://facebook.com/BuxtehudeAdventskalender2025"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 rounded-lg bg-christmas-red/10 text-christmas-red flex items-center justify-center hover:bg-christmas-red hover:text-white transition-colors"
                    aria-label="Facebook"
                  >
                    <Facebook className="h-5 w-5" />
                  </a>
                  <a
                    href="https://instagram.com/Buxtehude_Adventskalender"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 rounded-lg bg-christmas-red/10 text-christmas-red flex items-center justify-center hover:bg-christmas-red hover:text-white transition-colors"
                    aria-label="Instagram"
                  >
                    <Instagram className="h-5 w-5" />
                  </a>
                </div>
                <p className="text-xs text-muted-foreground mt-4">Verpasse keine Gewinnspiele und Updates!</p>
              </div>
            </div>

            {/* Bottom Bar */}
            <div className="pt-8 border-t border-border">
              <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-muted-foreground">
                <p>© 2025 Buxtehude Erlebnis-Adventskalender. Alle Rechte vorbehalten.</p>
                <p>
                  Ein Projekt von{" "}
                  <a
                    href="https://sspeag.de"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-christmas-red hover:underline"
                  >
                    SSPE AG
                  </a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </footer>

      <div className="fixed bottom-6 right-6 z-40">
        <Button
          size="lg"
          className="bg-christmas-red hover:bg-christmas-red/90 text-white shadow-2xl rounded-full h-14 px-6 animate-pulse hover:animate-none hover:scale-105 transition-all"
        >
          <Gift className="h-5 w-5 mr-2" />
          Jetzt kaufen!
        </Button>
      </div>
    </div>
  )
}
